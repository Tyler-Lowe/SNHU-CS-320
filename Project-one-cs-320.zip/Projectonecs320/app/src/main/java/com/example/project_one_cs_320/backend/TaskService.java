package com.example.project_one_cs_320.backend;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> taskList = new HashMap<>();

    public boolean addTask(Task task) {
        if (taskList.containsKey(task.getTaskID())) {
            return false;
        }
        taskList.put(task.getTaskID(), task);
        return true;
    }

    public boolean deleteTask(String taskID) {
        return taskList.remove(taskID) != null;
    }

    public boolean updateTask(String taskID, String name, String description) {
        Task task = taskList.get(taskID);
        if (task == null) {
            return false;
        }
        if (name != null && name.length() <= 20) {
            task.setName(name);
        }
        if (description != null && description.length() <= 50) {
            task.setDescription(description);
        }
        return true;
    }
}

