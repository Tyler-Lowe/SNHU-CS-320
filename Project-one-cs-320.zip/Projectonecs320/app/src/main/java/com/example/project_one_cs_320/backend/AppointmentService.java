package com.example.project_one_cs_320.backend;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private final Map<String, Appointment> appointmentList = new HashMap<>();

    public boolean addAppointment(Appointment appointment) {
        if (appointmentList.containsKey(appointment.getAppointmentID())) {
            return false;
        }
        appointmentList.put(appointment.getAppointmentID(), appointment);
        return true;
    }

    public boolean deleteAppointment(String appointmentID) {
        return appointmentList.remove(appointmentID) != null;
    }
}
