package com.example.project_one_cs_320.backend;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contactList = new HashMap<>();

    public boolean addContact(Contact contact) {
        if (contactList.containsKey(contact.getContactID())) {
            return false;
        }
        contactList.put(contact.getContactID(), contact);
        return true;
    }

    public boolean deleteContact(String contactID) {
        return contactList.remove(contactID) != null;
    }

    public boolean updateContact(String contactID, String firstName, String lastName, String phone, String address) {
        Contact contact = contactList.get(contactID);
        if (contact == null) {
            return false;
        }
        if (firstName != null && firstName.length() <= 10) {
            contact.setFirstName(firstName);
        }
        if (lastName != null && lastName.length() <= 10) {
            contact.setLastName(lastName);
        }
        if (phone != null && phone.length() == 10) {
            contact.setPhone(phone);
        }
        if (address != null && address.length() <= 30) {
            contact.setAddress(address);
        }
        return true;
    }
}
