import org.junit.Test;
import static org.junit.Assert.*;
import com.example.project_one_cs_320.backend.Contact;  // Import the Contact class

public class ContactTest {

    @Test
    public void testContactCreationSuccess() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("1234567890", contact.getContactID());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    @Test
    public void testContactCreationFailure() {
        try {
            new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St");
            fail("Expected IllegalArgumentException for contactID too long");
        } catch (IllegalArgumentException e) {
            // Test passed
        }
    }

    @Test
    public void testSettersSuccess() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contact.setFirstName("Jane");
        contact.setLastName("Smith");
        contact.setPhone("0987654321");
        contact.setAddress("456 Elm St");

        assertEquals("Jane", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("0987654321", contact.getPhone());
        assertEquals("456 Elm St", contact.getAddress());
    }

    @Test
    public void testSettersFailure() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(null);
        });
    }
}
