import org.junit.Test;
import static org.junit.Assert.*;
import com.example.project_one_cs_320.backend.Task;  // Import Task class

public class TaskTest {

    @Test
    public void testTaskCreationSuccess() {
        Task task = new Task("1234567890", "Complete assignment", "Finish the project assignment for CS 320");
        assertEquals("1234567890", task.getTaskID());
        assertEquals("Complete assignment", task.getName());
        assertEquals("Finish the project assignment for CS 320", task.getDescription());
    }

    @Test
    public void testTaskCreationFailureInvalidData() {
        try {
            new Task("12345678901", "Complete assignment", "Finish the project assignment for CS 320");
            fail("Expected IllegalArgumentException for taskID too long");
        } catch (IllegalArgumentException e) {
            // Test passed
        }

        try {
            new Task("1234567890", null, "Finish the project assignment for CS 320");
            fail("Expected IllegalArgumentException for null name");
        } catch (IllegalArgumentException e) {
            // Test passed
        }
    }
}
