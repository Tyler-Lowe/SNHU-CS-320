import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Date;
import java.util.Calendar;
import com.example.project_one_cs_320.backend.Appointment;
import com.example.project_one_cs_320.backend.AppointmentService;  // Ensure this import is added

public class AppointmentServiceTest {

    @Test
    public void testAddAppointmentSuccess() {
        AppointmentService service = new AppointmentService();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);  // 1 day in the future
        Date futureDate = calendar.getTime();

        Appointment appointment = new Appointment("1234567890", futureDate, "Doctor's appointment");
        assertTrue(service.addAppointment(appointment));
    }

    @Test
    public void testAddAppointmentDuplicateID() {
        AppointmentService service = new AppointmentService();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);  // 1 day in the future
        Date futureDate = calendar.getTime();

        Appointment appointment1 = new Appointment("1234567890", futureDate, "Doctor's appointment");
        Appointment appointment2 = new Appointment("1234567890", futureDate, "Dentist appointment");

        service.addAppointment(appointment1);
        assertFalse(service.addAppointment(appointment2));  // Duplicate appointment ID
    }

    @Test
    public void testDeleteAppointmentSuccess() {
        AppointmentService service = new AppointmentService();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);  // 1 day in the future
        Date futureDate = calendar.getTime();

        Appointment appointment = new Appointment("1234567890", futureDate, "Doctor's appointment");

        service.addAppointment(appointment);
        assertTrue(service.deleteAppointment("1234567890"));
    }

    @Test
    public void testDeleteAppointmentFailure() {
        AppointmentService service = new AppointmentService();
        assertFalse(service.deleteAppointment("NonExistentID"));
    }
}
