import org.junit.Test;
import static org.junit.Assert.*;
import com.example.project_one_cs_320.backend.Task;  // Import Task class
import com.example.project_one_cs_320.backend.TaskService;  // Import TaskService class

public class TaskServiceTest {

    @Test
    public void testAddTaskSuccess() {
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "Complete assignment", "Finish the project assignment for CS 320");
        assertTrue(service.addTask(task));
    }

    @Test
    public void testAddTaskDuplicateID() {
        TaskService service = new TaskService();
        Task task1 = new Task("1234567890", "Complete assignment", "Finish the project assignment for CS 320");
        Task task2 = new Task("1234567890", "Start new project", "Start the next project in the course");

        service.addTask(task1);
        assertFalse(service.addTask(task2));  // Duplicate task ID
    }

    @Test
    public void testDeleteTaskSuccess() {
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "Complete assignment", "Finish the project assignment for CS 320");

        service.addTask(task);
        assertTrue(service.deleteTask("1234567890"));
    }

    @Test
    public void testDeleteTaskFailure() {
        TaskService service = new TaskService();
        assertFalse(service.deleteTask("NonExistentID"));
    }
}
