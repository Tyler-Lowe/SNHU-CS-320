import org.junit.Test;
import static org.junit.Assert.*;
import com.example.project_one_cs_320.backend.Contact;  // Import Contact class
import com.example.project_one_cs_320.backend.ContactService;  // Import ContactService class

public class ContactServiceTest {

    @Test
    public void testAddContactSuccess() {
        ContactService service = new ContactService();
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        assertTrue(service.addContact(contact));
    }

    @Test
    public void testAddContactDuplicateID() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        Contact contact2 = new Contact("1234567890", "Jane", "Smith", "0987654321", "456 Elm St");

        service.addContact(contact1);
        assertFalse(service.addContact(contact2));  // Duplicate contact ID
    }

    @Test
    public void testDeleteContactSuccess() {
        ContactService service = new ContactService();
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");

        service.addContact(contact);
        assertTrue(service.deleteContact("1234567890"));
    }

    @Test
    public void testDeleteContactFailure() {
        ContactService service = new ContactService();
        assertFalse(service.deleteContact("NonExistentID"));
    }

    @Test
    public void testUpdateContactSuccess() {
        ContactService service = new ContactService();
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");

        service.addContact(contact);
        assertTrue(service.updateContact("1234567890", "Jane", "Smith", "0987654321", "456 Elm St"));
    }

    @Test
    public void testUpdateContactFailure() {
        ContactService service = new ContactService();
        assertFalse(service.updateContact("NonExistentID", "Jane", "Smith", "0987654321", "456 Elm St"));
    }
}
