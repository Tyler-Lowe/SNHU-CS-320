import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Date;
import java.util.Calendar;
import com.example.project_one_cs_320.backend.Appointment;  // Import Appointment class

public class AppointmentTest {

    @Test
    public void testAppointmentCreationSuccess() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);  // Set date to 1 day in the future
        Date futureDate = calendar.getTime();

        Appointment appointment = new Appointment("1234567890", futureDate, "Doctor's appointment");
        assertEquals("1234567890", appointment.getAppointmentID());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Doctor's appointment", appointment.getDescription());
    }

    @Test
    public void testAppointmentCreationFailure() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, -1);  // Set date to 1 day in the past
        Date pastDate = calendar.getTime();

        try {
            new Appointment("1234567890", pastDate, "Doctor's appointment");
            fail("Expected IllegalArgumentException for appointmentDate in the past");
        } catch (IllegalArgumentException e) {
            // Test passed
        }
    }
}
